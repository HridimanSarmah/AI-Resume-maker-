require 'sinatra'
require 'json'

# Define a basic route
get '/' do
  content_type :json
  { message: "Welcome to the AI Resume Maker!" }.to_json
end

# Optional: Add a resume route
post '/resume' do
  request_payload = JSON.parse(request.body.read)

  name = request_payload["name"] || "Unknown"
  position = request_payload["position"] || "Undefined"

  content_type :json
  {
    message: "Resume created for #{name} applying for #{position}"
  }.to_json
end
