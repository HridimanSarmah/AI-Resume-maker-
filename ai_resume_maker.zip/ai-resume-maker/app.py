
from flask import Flask, render_template, request, make_response
import openai
import pdfkit

app = Flask(__name__)
openai.api_key = 'YOUR_OPENAI_API_KEY'

def generate_summary(name, skills, experience):
    prompt = f"Create a professional resume summary for {name} with skills: {skills} and experience: {experience}."
    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=prompt,
        max_tokens=100
    )
    return response.choices[0].text.strip()

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/resume', methods=['POST'])
def resume():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    education = request.form['education']
    skills = request.form['skills']
    experience = request.form['experience']
    template = request.form.get('template', 'default')

    summary = generate_summary(name, skills, experience)

    if template == "alt":
        return render_template('resume_alt.html', name=name, email=email, phone=phone,
                               education=education, skills=skills, experience=experience, summary=summary)
    else:
        return render_template('resume.html', name=name, email=email, phone=phone,
                               education=education, skills=skills, experience=experience, summary=summary)

@app.route('/download-pdf', methods=['POST'])
def download_pdf():
    resume_html = request.form['html']
    pdf = pdfkit.from_string(resume_html, False)
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=resume.pdf'
    return response

if __name__ == '__main__':
    app.run(debug=True)
