
# AI Resume Maker

Generate professional resumes with AI using Flask + OpenAI.

## Features
- AI-generated resume summaries
- Multiple templates
- PDF export

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Set your OpenAI API key in `app.py`

3. Run the app:
   ```
   python app.py
   ```

4. Visit `http://localhost:5000`

## License
MIT
